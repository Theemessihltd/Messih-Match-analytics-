# Messih Match Analytics — MVP

A complete runnable MVP for football match analytics and predictions.

## Stack

- Next.js frontend
- Express API
- Python FastAPI prediction engine
- PostgreSQL
- Docker Compose

## Quick start

1. Install Docker Desktop.
2. Copy `.env.example` to `.env`.
3. Run:

```bash
docker compose up --build
```

4. Open:
   - Web: http://localhost:3000
   - API: http://localhost:4000/health
   - AI: http://localhost:8000/health

The MVP ships with demo match/team data so the full product can be tested without an external football API.

## API

- `GET /health`
- `GET /api/matches`
- `GET /api/matches/:id`
- `GET /api/predictions`
- `POST /api/predictions`

## Prediction model

The initial model is a transparent baseline using weighted form, attack, defense, home advantage, and goal expectations. It is intentionally not presented as a guaranteed outcome.

To move to production:
1. Connect a licensed football data provider.
2. Store historical match data.
3. Train and validate a stronger model.
4. Calibrate probabilities.
5. Track every prediction before the result is known.
6. Evaluate accuracy and calibration over time.

## Project structure

```text
apps/
  web/      Next.js UI
  api/      Express API
  ai/       FastAPI prediction service
database/
  init.sql
```
