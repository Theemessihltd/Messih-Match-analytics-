
from fastapi import FastAPI
from pydantic import BaseModel
import math

app = FastAPI(title="Messih Match Analytics AI")

class Team(BaseModel):
    name: str
    wins: int
    draws: int
    losses: int
    goals_for: float
    goals_against: float
    xg: float
    xga: float
    home_strength: float = 1.0
    away_strength: float = 1.0

class PredictionRequest(BaseModel):
    home: Team
    away: Team

def clamp(x, lo=0.02, hi=0.96):
    return max(lo, min(hi, x))

def sigmoid(x):
    return 1 / (1 + math.exp(-x))

@app.get("/health")
def health():
    return {"status": "ok", "model": "baseline-v1"}

@app.post("/predict")
def predict(req: PredictionRequest):
    h, a = req.home, req.away

    h_form = (h.wins * 3 + h.draws) / max(1, (h.wins + h.draws + h.losses) * 3)
    a_form = (a.wins * 3 + a.draws) / max(1, (a.wins + a.draws + a.losses) * 3)

    h_attack = (h.xg / max(1, h.goals_for)) if h.goals_for else 1
    a_attack = (a.xg / max(1, a.goals_for)) if a.goals_for else 1

    h_strength = (h_form * 0.55) + (h.home_strength * 0.25) + (h_attack * 0.20)
    a_strength = (a_form * 0.55) + (a.away_strength * 0.25) + (a_attack * 0.20)

    edge = (h_strength - a_strength) * 3.2 + 0.28
    home_raw = sigmoid(edge)
    away_raw = sigmoid(-edge)
    draw_raw = 0.30 - abs(h_strength - a_strength) * 0.12

    total = home_raw + away_raw + max(0.08, draw_raw)
    home_p = clamp(home_raw / total)
    draw_p = clamp(max(0.08, draw_raw) / total)
    away_p = clamp(away_raw / total)

    home_goals = max(0.2, (h.xg / 20) * 1.15 * h.home_strength)
    away_goals = max(0.2, (a.xg / 20) * 1.05 * a.away_strength)

    total_goals = home_goals + away_goals
    over25 = clamp(1 - math.exp(-0.52 * total_goals))
    btts = clamp((1 - math.exp(-home_goals)) * (1 - math.exp(-away_goals)))

    probs = sorted([home_p, draw_p, away_p], reverse=True)
    confidence = clamp(0.50 + (probs[0] - probs[1]) * 1.25)

    if home_p >= draw_p and home_p >= away_p:
        outcome = f"{h.name} are favored to win"
    elif away_p >= home_p and away_p >= draw_p:
        outcome = f"{a.name} are favored to win"
    else:
        outcome = "A draw is the model's leading result"

    explanation = (
        f"{outcome}. The baseline model weighs recent results, attacking output, "
        f"expected goals, home advantage and away strength. "
        f"The model estimates {home_goals:.1f} home goals and {away_goals:.1f} away goals."
    )

    return {
        "home_probability": round(home_p * 100, 1),
        "draw_probability": round(draw_p * 100, 1),
        "away_probability": round(away_p * 100, 1),
        "over25_probability": round(over25 * 100, 1),
        "btts_probability": round(btts * 100, 1),
        "predicted_home_goals": round(home_goals, 1),
        "predicted_away_goals": round(away_goals, 1),
        "confidence": round(confidence * 100, 1),
        "explanation": explanation,
        "model_version": "baseline-v1"
    }
