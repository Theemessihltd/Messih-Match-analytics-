
const express = require("express");
const cors = require("cors");
const { Pool } = require("pg");

const app = express();
app.use(cors());
app.use(express.json());

const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});

const AI_URL = process.env.AI_URL || "http://ai:8000";
const PORT = process.env.PORT || 4000;

app.get("/health", async (req, res) => {
  try {
    await pool.query("SELECT 1");
    res.json({ status: "ok", database: "connected" });
  } catch (e) {
    res.status(503).json({ status: "error", message: e.message });
  }
});

app.get("/api/matches", async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT m.id, m.league, m.kickoff, m.status,
             h.name AS home_team, h.short_name AS home_short,
             a.name AS away_team, a.short_name AS away_short
      FROM matches m
      JOIN teams h ON h.id = m.home_team_id
      JOIN teams a ON a.id = m.away_team_id
      ORDER BY m.kickoff ASC
    `);
    res.json(result.rows);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get("/api/matches/:id", async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT m.*, h.name AS home_team, a.name AS away_team
      FROM matches m
      JOIN teams h ON h.id = m.home_team_id
      JOIN teams a ON a.id = m.away_team_id
      WHERE m.id=$1
    `, [req.params.id]);

    if (!result.rows[0]) return res.status(404).json({ error: "Match not found" });
    res.json(result.rows[0]);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get("/api/predictions", async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT p.*, h.name AS home_team, a.name AS away_team, m.league, m.kickoff
      FROM predictions p
      JOIN matches m ON m.id=p.match_id
      JOIN teams h ON h.id=m.home_team_id
      JOIN teams a ON a.id=m.away_team_id
      ORDER BY p.created_at DESC
    `);
    res.json(result.rows);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post("/api/predictions", async (req, res) => {
  const { matchId } = req.body;
  try {
    const match = await pool.query(`
      SELECT m.id, h.name AS home_name, a.name AS away_name,
             hs.wins AS hwins, hs.draws AS hdraws, hs.losses AS hlosses,
             hs.goals_for AS hgf, hs.goals_against AS hga, hs.xg AS hxg, hs.xga AS hxga,
             hs.home_strength AS hhome_strength,
             as2.wins AS awins, as2.draws AS adraws, as2.losses AS alosses,
             as2.goals_for AS agf, as2.goals_against AS aga, as2.xg AS axg, as2.xga AS axga,
             as2.away_strength AS aaway_strength
      FROM matches m
      JOIN teams h ON h.id=m.home_team_id
      JOIN teams a ON a.id=m.away_team_id
      JOIN team_stats hs ON hs.team_id=h.id
      JOIN team_stats as2 ON as2.team_id=a.id
      WHERE m.id=$1
    `, [matchId]);

    if (!match.rows[0]) return res.status(404).json({ error: "Match not found" });

    const r = match.rows[0];
    const payload = {
      home: {
        name: r.home_name, wins: r.hwins, draws: r.hdraws, losses: r.hlosses,
        goals_for: Number(r.hgf), goals_against: Number(r.hga), xg: Number(r.hxg),
        xga: Number(r.hxga), home_strength: Number(r.hhome_strength), away_strength: 1
      },
      away: {
        name: r.away_name, wins: r.awins, draws: r.adraws, losses: r.alosses,
        goals_for: Number(r.agf), goals_against: Number(r.aga), xg: Number(r.axg),
        xga: Number(r.axga), home_strength: 1, away_strength: Number(r.aaway_strength)
      }
    };

    const aiResponse = await fetch(`${AI_URL}/predict`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    if (!aiResponse.ok) throw new Error("AI service failed");
    const prediction = await aiResponse.json();

    const saved = await pool.query(`
      INSERT INTO predictions
      (match_id, home_probability, draw_probability, away_probability,
       over25_probability, btts_probability, predicted_home_goals,
       predicted_away_goals, confidence, explanation, model_version)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
      RETURNING *
    `, [
      matchId, prediction.home_probability, prediction.draw_probability,
      prediction.away_probability, prediction.over25_probability,
      prediction.btts_probability, prediction.predicted_home_goals,
      prediction.predicted_away_goals, prediction.confidence,
      prediction.explanation, prediction.model_version
    ]);

    res.json(saved.rows[0]);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.listen(PORT, () => console.log(`API running on ${PORT}`));
