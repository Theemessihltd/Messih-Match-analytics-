
'use client';

import { useEffect, useState } from 'react';

const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000';

function Stat({ label, value }) {
  return (
    <div className="stat">
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}

export default function Home() {
  const [matches, setMatches] = useState([]);
  const [predictions, setPredictions] = useState({});
  const [loading, setLoading] = useState(true);
  const [active, setActive] = useState(null);

  useEffect(() => {
    fetch(`${API}/api/matches`)
      .then(r => r.json())
      .then(data => { setMatches(data); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  async function predict(id) {
    setActive(id);
    try {
      const r = await fetch(`${API}/api/predictions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ matchId: id })
      });
      const data = await r.json();
      setPredictions(p => ({ ...p, [id]: data }));
    } catch (e) {
      alert('Prediction service unavailable.');
    } finally {
      setActive(null);
    }
  }

  return (
    <main>
      <header className="nav">
        <div className="brand">
          <div className="logo">M</div>
          <div>
            <b>MESSIH</b>
            <span>MATCH ANALYTICS</span>
          </div>
        </div>
        <nav>
          <a href="#matches">Matches</a>
          <a href="#predictions">Predictions</a>
          <a href="#analytics">Analytics</a>
        </nav>
        <button className="outline">Sign In</button>
      </header>

      <section className="hero">
        <div className="hero-copy">
          <p className="eyebrow">FOOTBALL INTELLIGENCE PLATFORM</p>
          <h1>Predict smarter.<br /><em>Analyze deeper.</em></h1>
          <p className="lead">
            Data-driven football analysis with transparent AI-powered predictions,
            match statistics and model performance tracking.
          </p>
          <a className="primary" href="#matches">Explore Matches →</a>
        </div>
        <div className="hero-card">
          <div className="card-label">AI MODEL STATUS</div>
          <div className="pulse"><i /> ONLINE</div>
          <div className="big-number">Baseline v1</div>
          <p>Transparent statistical prediction engine</p>
        </div>
      </section>

      <section className="metrics" id="analytics">
        <Stat label="Model Version" value="v1" />
        <Stat label="Prediction Types" value="5" />
        <Stat label="Live Data" value="MVP" />
        <Stat label="Confidence" value="Dynamic" />
      </section>

      <section className="section" id="matches">
        <div className="section-head">
          <div>
            <p className="eyebrow">UPCOMING FIXTURES</p>
            <h2>Today's Match Centre</h2>
          </div>
          <span className="badge">DEMO DATA</span>
        </div>

        {loading ? <p>Loading matches...</p> : (
          <div className="matches">
            {matches.map(match => {
              const p = predictions[match.id];
              return (
                <article className="match-card" key={match.id}>
                  <div className="league">{match.league}</div>
                  <div className="match-top">
                    <span>{new Date(match.kickoff).toLocaleString()}</span>
                    <span className="status">{match.status}</span>
                  </div>
                  <div className="teams">
                    <div><strong>{match.home_team}</strong><small>{match.home_short}</small></div>
                    <span className="vs">VS</span>
                    <div><strong>{match.away_team}</strong><small>{match.away_short}</small></div>
                  </div>

                  {!p ? (
                    <button className="predict" onClick={() => predict(match.id)} disabled={active === match.id}>
                      {active === match.id ? 'Analyzing...' : 'Generate AI Prediction'}
                    </button>
                  ) : (
                    <div className="prediction" id="predictions">
                      <div className="probabilities">
                        <div><span>HOME</span><b>{p.home_probability}%</b></div>
                        <div><span>DRAW</span><b>{p.draw_probability}%</b></div>
                        <div><span>AWAY</span><b>{p.away_probability}%</b></div>
                      </div>
                      <div className="prediction-grid">
                        <Stat label="Over 2.5" value={`${p.over25_probability}%`} />
                        <Stat label="BTTS" value={`${p.btts_probability}%`} />
                        <Stat label="Confidence" value={`${p.confidence}%`} />
                        <Stat label="Score" value={`${p.predicted_home_goals}–${p.predicted_away_goals}`} />
                      </div>
                      <p className="explanation">{p.explanation}</p>
                      <small className="model">Model: {p.model_version}</small>
                    </div>
                  )}
                </article>
              );
            })}
          </div>
        )}
      </section>

      <section className="section methodology">
        <p className="eyebrow">OUR APPROACH</p>
        <h2>Transparent analytics, not guaranteed outcomes.</h2>
        <p>
          Messih Match Analytics uses statistical signals such as form, attacking output,
          expected goals and home/away strength. Predictions are probabilities, not certainties.
          Every production prediction should be stored and evaluated against the eventual result.
        </p>
      </section>

      <footer>
        <div className="brand"><div className="logo">M</div><b>MESSIH MATCH ANALYTICS</b></div>
        <span>© 2026 Messih Match Analytics. MVP.</span>
      </footer>
    </main>
  );
}
