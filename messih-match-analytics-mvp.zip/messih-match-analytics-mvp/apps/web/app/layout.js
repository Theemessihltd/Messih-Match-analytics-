import './globals.css';

export const metadata = {
  title: 'Messih Match Analytics',
  description: 'Football intelligence and AI-powered match analysis.'
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
