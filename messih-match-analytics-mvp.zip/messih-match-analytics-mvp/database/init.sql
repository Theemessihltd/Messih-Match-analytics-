
CREATE TABLE IF NOT EXISTS teams (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  short_name TEXT NOT NULL,
  league TEXT NOT NULL,
  logo TEXT
);

CREATE TABLE IF NOT EXISTS matches (
  id SERIAL PRIMARY KEY,
  home_team_id INTEGER NOT NULL REFERENCES teams(id),
  away_team_id INTEGER NOT NULL REFERENCES teams(id),
  league TEXT NOT NULL,
  kickoff TIMESTAMPTZ NOT NULL,
  status TEXT NOT NULL DEFAULT 'SCHEDULED',
  home_score INTEGER,
  away_score INTEGER
);

CREATE TABLE IF NOT EXISTS team_stats (
  team_id INTEGER PRIMARY KEY REFERENCES teams(id),
  played INTEGER NOT NULL DEFAULT 0,
  wins INTEGER NOT NULL DEFAULT 0,
  draws INTEGER NOT NULL DEFAULT 0,
  losses INTEGER NOT NULL DEFAULT 0,
  goals_for NUMERIC NOT NULL DEFAULT 0,
  goals_against NUMERIC NOT NULL DEFAULT 0,
  xg NUMERIC NOT NULL DEFAULT 0,
  xga NUMERIC NOT NULL DEFAULT 0,
  home_strength NUMERIC NOT NULL DEFAULT 1,
  away_strength NUMERIC NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS predictions (
  id SERIAL PRIMARY KEY,
  match_id INTEGER NOT NULL REFERENCES matches(id),
  home_probability NUMERIC NOT NULL,
  draw_probability NUMERIC NOT NULL,
  away_probability NUMERIC NOT NULL,
  over25_probability NUMERIC NOT NULL,
  btts_probability NUMERIC NOT NULL,
  predicted_home_goals NUMERIC NOT NULL,
  predicted_away_goals NUMERIC NOT NULL,
  confidence NUMERIC NOT NULL,
  explanation TEXT NOT NULL,
  model_version TEXT NOT NULL DEFAULT 'baseline-v1',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO teams (name, short_name, league) VALUES
('Arsenal', 'ARS', 'Premier League'),
('Chelsea', 'CHE', 'Premier League'),
('Manchester City', 'MCI', 'Premier League'),
('Liverpool', 'LIV', 'Premier League'),
('Barcelona', 'BAR', 'La Liga'),
('Real Madrid', 'RMA', 'La Liga')
ON CONFLICT (name) DO NOTHING;

INSERT INTO team_stats
(team_id, played, wins, draws, losses, goals_for, goals_against, xg, xga, home_strength, away_strength)
SELECT id, 20, 13, 4, 3, 42, 21, 40.5, 20.2, 1.18, 1.04 FROM teams WHERE name='Arsenal'
ON CONFLICT (team_id) DO NOTHING;

INSERT INTO team_stats
SELECT id, 20, 9, 5, 6, 34, 29, 35.2, 28.7, 1.08, 0.96 FROM teams WHERE name='Chelsea'
ON CONFLICT (team_id) DO NOTHING;

INSERT INTO team_stats
SELECT id, 20, 15, 3, 2, 50, 18, 48.1, 17.4, 1.24, 1.10 FROM teams WHERE name='Manchester City'
ON CONFLICT (team_id) DO NOTHING;

INSERT INTO team_stats
SELECT id, 20, 14, 4, 2, 47, 22, 45.8, 21.1, 1.19, 1.08 FROM teams WHERE name='Liverpool'
ON CONFLICT (team_id) DO NOTHING;

INSERT INTO team_stats
SELECT id, 20, 15, 3, 2, 49, 19, 47.5, 18.3, 1.21, 1.09 FROM teams WHERE name='Barcelona'
ON CONFLICT (team_id) DO NOTHING;

INSERT INTO team_stats
SELECT id, 20, 16, 2, 2, 53, 17, 51.2, 16.5, 1.23, 1.11 FROM teams WHERE name='Real Madrid'
ON CONFLICT (team_id) DO NOTHING;

INSERT INTO matches (home_team_id, away_team_id, league, kickoff)
SELECT h.id, a.id, 'Premier League', NOW() + INTERVAL '1 day'
FROM teams h, teams a
WHERE h.name='Arsenal' AND a.name='Chelsea'
AND NOT EXISTS (
  SELECT 1 FROM matches m WHERE m.home_team_id=h.id AND m.away_team_id=a.id
);

INSERT INTO matches (home_team_id, away_team_id, league, kickoff)
SELECT h.id, a.id, 'Premier League', NOW() + INTERVAL '2 days'
FROM teams h, teams a
WHERE h.name='Manchester City' AND a.name='Liverpool'
AND NOT EXISTS (
  SELECT 1 FROM matches m WHERE m.home_team_id=h.id AND m.away_team_id=a.id
);

INSERT INTO matches (home_team_id, away_team_id, league, kickoff)
SELECT h.id, a.id, 'La Liga', NOW() + INTERVAL '3 days'
FROM teams h, teams a
WHERE h.name='Barcelona' AND a.name='Real Madrid'
AND NOT EXISTS (
  SELECT 1 FROM matches m WHERE m.home_team_id=h.id AND m.away_team_id=a.id
);
