const matches = [
  { home: "Manchester City", away: "Arsenal", league: "Premier League", homeWin: 56, draw: 24, awayWin: 20, score: "2–1", confidence: 82 },
  { home: "Barcelona", away: "Real Madrid", league: "La Liga", homeWin: 44, draw: 27, awayWin: 29, score: "2–2", confidence: 71 },
  { home: "Bayern Munich", away: "Dortmund", league: "Bundesliga", homeWin: 63, draw: 21, awayWin: 16, score: "3–1", confidence: 86 }
];

export default function Home() {
  return (
    <main>
      <nav className="nav">
        <div className="brand"><span className="logo">M</span> Messih Match Analytics</div>
        <div className="links"><a href="#predictions">Predictions</a><a href="#features">Analytics</a><a href="#about">About</a></div>
      </nav>

      <section className="hero">
        <div>
          <p className="eyebrow">DATA • AI • FOOTBALL</p>
          <h1>Smarter football insights, powered by data.</h1>
          <p className="lead">Messih Match Analytics combines football statistics and machine learning to generate original match analysis and prediction probabilities.</p>
          <a className="cta" href="#predictions">Explore predictions</a>
        </div>
        <div className="heroCard">
          <span>AI MODEL STATUS</span>
          <strong>Prediction Engine</strong>
          <small>Ready for historical data training</small>
          <div className="meter"><i /></div>
        </div>
      </section>

      <section id="predictions" className="section">
        <div className="sectionHead"><div><p className="eyebrow">TODAY'S INSIGHTS</p><h2>Featured predictions</h2></div><span className="badge">MMA AI v0.1</span></div>
        <div className="grid">
          {matches.map((m) => (
            <article className="card" key={m.home}>
              <span className="league">{m.league}</span>
              <h3>{m.home} <em>vs</em> {m.away}</h3>
              <div className="prob">
                <div><b>{m.homeWin}%</b><span>Home</span></div>
                <div><b>{m.draw}%</b><span>Draw</span></div>
                <div><b>{m.awayWin}%</b><span>Away</span></div>
              </div>
              <div className="row"><span>Predicted score</span><strong>{m.score}</strong></div>
              <div className="row"><span>Confidence</span><strong>{m.confidence}%</strong></div>
              <p className="disclaimer">Demo prediction data for product development. Not a guarantee of match results.</p>
            </article>
          ))}
        </div>
      </section>

      <section id="features" className="section features">
        <div><p className="eyebrow">THE MMA PLATFORM</p><h2>Built for serious football analysis.</h2></div>
        <div className="featureGrid">
          {["AI match probabilities", "Team form & head-to-head", "Live data integration", "Model accuracy tracking"].map((x) => <div className="feature" key={x}><span>01</span><h3>{x}</h3><p>Designed to combine reliable football data with transparent, measurable analytics.</p></div>)}
        </div>
      </section>

      <footer id="about">© 2026 Messih Match Analytics. AI-generated insights should be used responsibly.</footer>
    </main>
  );
}