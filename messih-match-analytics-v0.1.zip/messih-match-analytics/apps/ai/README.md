# MMA AI Service

This directory is the starting point for the proprietary Messih Match Analytics prediction engine.

Planned pipeline:
1. Ingest historical fixtures and team statistics.
2. Engineer features: Elo, form, home advantage, goals, xG, shots, rest days.
3. Train models for 1X2 and goal markets.
4. Back-test with time-based splits.
5. Calibrate probabilities.
6. Serve predictions through FastAPI.

Do not present demo predictions as real model output until the model has been trained and validated.
