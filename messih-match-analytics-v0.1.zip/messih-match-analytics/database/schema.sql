CREATE TABLE IF NOT EXISTS teams (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  league TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS matches (
  id SERIAL PRIMARY KEY,
  home_team_id INT REFERENCES teams(id),
  away_team_id INT REFERENCES teams(id),
  kickoff TIMESTAMPTZ NOT NULL,
  home_score INT,
  away_score INT,
  status TEXT DEFAULT 'scheduled'
);

CREATE TABLE IF NOT EXISTS predictions (
  id SERIAL PRIMARY KEY,
  match_id INT REFERENCES matches(id),
  model_version TEXT NOT NULL,
  home_win NUMERIC NOT NULL,
  draw NUMERIC NOT NULL,
  away_win NUMERIC NOT NULL,
  predicted_home_goals NUMERIC,
  predicted_away_goals NUMERIC,
  confidence NUMERIC,
  created_at TIMESTAMPTZ DEFAULT NOW()
);